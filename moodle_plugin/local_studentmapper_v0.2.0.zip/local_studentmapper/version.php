<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_studentmapper';
$plugin->version   = 2024011000;
$plugin->requires  = 2022112800; // Moodle 4.1 compatible
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = 'v0.2.0';
