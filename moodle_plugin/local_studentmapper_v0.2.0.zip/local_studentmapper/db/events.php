<?php
defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\user_created',
        'callback' => 'local_studentmapper\observer::store',
    ],
    [
        'eventname' => '\core\event\user_updated',
        'callback' => 'local_studentmapper\observer::store',
    ],
];
